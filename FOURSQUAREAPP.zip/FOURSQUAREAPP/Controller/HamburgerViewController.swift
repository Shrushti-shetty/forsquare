//
//  HamburgerViewController.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 31/12/22.
//

import UIKit

class HamburgerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
  

}
