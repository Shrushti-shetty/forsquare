//
//  ContentViewController.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 30/12/22.
//

import UIKit

class ContentViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
  
    @IBOutlet weak var tableView: UITableView!
    
    var index: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.register(UINib(nibName: "DetailsCell", bundle: nil), forCellReuseIdentifier: "Cell")
        tableView.register(UINib(nibName: "MapCell", bundle: nil), forCellReuseIdentifier: "MapCell")

    }
    override func viewWillAppear(_ animated: Bool) {
        print("xyz", index)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if index == 0{
            return 5 + 1
        }
        else {
            return 5
        }
       
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if index == 0{
            if indexPath.row == 0 {
              //  return UITableViewCell()
                    let cell = tableView.dequeueReusableCell(withIdentifier: "MapCell") as? MapTableViewCell
                cell?.getLocation()
                return cell!
            }
            else {
                //return UITableViewCell()
                let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? ContentTableViewCell ?? UITableViewCell()
                    return cell
            }
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "Cell") as? ContentTableViewCell ?? UITableViewCell()
                return cell
        }
    }
}
