//
//  DetailsViewController.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 02/01/23.
//

import UIKit
import MapKit

class DetailsViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }
    

   
}
