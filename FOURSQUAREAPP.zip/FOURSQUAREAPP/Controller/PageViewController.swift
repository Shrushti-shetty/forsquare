//
//  PageViewController.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 30/12/22.
//

import UIKit

class PageViewController: UIPageViewController, UIPageViewControllerDelegate, UIPageViewControllerDataSource{
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        if let startingViewController = createContentView(at: 0){
            setViewControllers([startingViewController], direction: .forward, animated: true, completion: nil)
        }
    
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        if let vc = viewController as? ContentViewController{
            var index = vc.index
            index -= 1
            return createContentView(at: index)
        }
        return nil
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        if let vc = viewController as? ContentViewController{
            var index = vc.index
            index += 1
            return createContentView(at: index)
        }
        return nil
    }
    
    func createContentView(at index: Int) -> ContentViewController?{
        if index < 0 || index >= 5{
            return nil
        }
        if let vc = storyboard?.instantiateViewController(withIdentifier: "ContentViewController") as? ContentViewController{
        vc.index = index
        return vc
        }
        return nil
    }

}
