//
//  MapTableViewCell.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 31/12/22.
//

import UIKit
import MapKit
import CoreLocation
class MapTableViewCell: UITableViewCell, CLLocationManagerDelegate {
    @IBOutlet weak var mapView: MKMapView!
    let locationManager = CLLocationManager()
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

    }
    
    func getLocation(){
        mapView.delegate = self
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        if CLLocationManager.locationServicesEnabled() {
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
            locationManager.startUpdatingLocation()
            
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        let pin = MKPointAnnotation()
        pin.coordinate = manager.location!.coordinate
        self.mapView.setRegion(MKCoordinateRegion(center: manager.location!.coordinate, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)), animated: true)
        self.mapView.addAnnotation(pin)
    }
}

extension MapTableViewCell: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        let anview = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        anview.image = #imageLiteral(resourceName: "rating_icon_selected")
        return anview
    }
}
