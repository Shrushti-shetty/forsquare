//
//  UserActionCollectionViewCell.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 30/12/22.
//

import UIKit

class UserActionCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var userActionLabel: UILabel!
    
    func configure(with userAction: String) {
        userActionLabel.text = userAction
    }
    
}
